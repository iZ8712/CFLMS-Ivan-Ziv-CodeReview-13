<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation \Request;

use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

use App\Entity\Eventv;



class EventsController extends AbstractController
{
    /**
     * @Route("/", name="home")
     */
    public function show()
    {
         
        $events = $this->getDoctrine()->getRepository( 'App:Eventv')->findAll();
      
        return $this ->render('events/index.html.twig', array('events'=>$events));

    }

    /**
     * @Route("/create", name="create")
     */
    public function  create(Request $request)
    {
        $events = new Eventv;

        $form = $this->createFormBuilder($events)
        ->add( 'img', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px', 'placeholder'=> "Only URL of Image")))
        ->add( 'name', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px', 'placeholder'=> "Name of the event")))
        ->add( 'eventdate', DateTimeType::class, array ( 'attr'  => array ( 'style' => 'margin-bottom:15px')))
        ->add( 'description', TextareaType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px', 'placeholder'=> "Short description of the event" )))
        ->add( 'capacity', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px', 'placeholder'=> "Maximum number of people")))
        ->add( 'email', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px', 'placeholder'=> "Email of the organizer")))
        ->add( 'phone', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px', 'placeholder'=> "Phone number of the organizer")))
        ->add( 'address', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px', 'placeholder'=> "Address of the event location")))
        ->add( 'zip', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px', 'placeholder'=> "Zip were the event location is")))
        ->add( 'city', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px', 'placeholder'=> "City were the event location is")))
        ->add( 'url', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px' , 'placeholder'=> "URL Link for more information")))

        ->add( 'save' , SubmitType::class, array ( 'label' => 'Create Event' , 'attr'  => array ( 'class' => 'btn-primary' , 'style' => 'margin-bottom:15px' )))
        ->getForm();
        $form->handleRequest($request);
        
        if ($form->isSubmitted() && $form->isValid()){ 
            
            $img = $form[ 'img' ]->getData();
            $name = $form[ 'name' ]->getData();
            $eventdate = $form[ 'eventdate' ]->getData();
            $description = $form[ 'description' ]->getData();
            $capacity = $form[ 'capacity' ]->getData();
            $email = $form[ 'email' ]->getData();
            $phone = $form[ 'phone' ]->getData();
            $address = $form[ 'address' ]->getData();
            $zip = $form[ 'zip' ]->getData();
            $city = $form[ 'city' ]->getData();
            $url = $form[ 'url' ]->getData();

            $events->setImg($img);
            $events->setName($name);
            $events->setEventdate($eventdate);
            $events->setDescription($description);
            $events->setCapacity($capacity);
            $events->setEmail($email);
            $events->setPhone($phone);
            $events->setAddress($address);
            $events->setZip($zip);
            $events->setCity($city);
            $events->setUrl($url);
            
            $em = $this ->getDoctrine()->getManager();
            $em->persist($events);
            $em->flush();
             $this ->addFlash(
                     'notice' ,
                     'Eventv Added'
                    );
             return   $this ->redirectToRoute( 'home' );
        }
         return   $this ->render( '/events/create.html.twig' , array ( 'form'  => $form->createView()));
    }

    /**
     * @Route("/edit/{id}", name="edit")
     */
    public function edit($id, Request $request)
    {
        
        $events = $this->getDoctrine()->getRepository('App:Eventv')->find($id);

            $events->setImg($events->getImg());
            $events->setName($events->getName());
            $events->setEventdate($events->getEventdate());
            $events->setDescription($events->getDescription());
            $events->setCapacity($events->getCapacity());
            $events->setEmail($events->getEmail());
            $events->setPhone($events->getPhone());
            $events->setAddress($events->getAddress());
            $events->setZip($events->getZip());
            $events->setCity($events->getCity());
            $events->setUrl($events->getUrl());
        
            $form = $this->createFormBuilder($events)
            ->add( 'img', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add( 'name', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add( 'eventdate', DateTimeType::class, array ( 'attr'  => array ( 'style' => 'margin-bottom:15px' )))
            ->add( 'description', TextareaType::class, array( 'attr' => array( 'class'=> 'form-control' , 'style' => 'margin-bottom:15px' )))
            ->add( 'capacity', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add( 'email', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add( 'phone', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add( 'address', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add( 'zip', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add( 'city', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))
            ->add( 'url', TextType::class, array ('attr' => array('class' => 'form-control' , 'style'=> 'margin-bottom:15px')))

            ->add('save', SubmitType::class, array('label'=> 'Update Event' , 'attr' => array( 'class'=> 'btn-primary', 'style' =>'margin-botton:15px')))
       ->getForm();
       $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            
            
            $img = $form[ 'img' ]->getData();
            $name = $form[ 'name' ]->getData();
            $eventdate = $form[ 'eventdate' ]->getData();
            $description = $form[ 'description' ]->getData();
            $capacity = $form[ 'capacity' ]->getData();
            $email = $form[ 'email' ]->getData();
            $phone = $form[ 'phone' ]->getData();
            $address = $form[ 'address' ]->getData();
            $zip = $form[ 'zip' ]->getData();
            $city = $form[ 'city' ]->getData();
            $url = $form[ 'url' ]->getData();

           $em = $this->getDoctrine()->getManager();
           $events = $em->getRepository( 'App:Eventv')->find($id);
           $events->setImg($img);
            $events->setName($name);
            $events->setEventdate($eventdate);
            $events->setDescription($description);
            $events->setCapacity($capacity);
            $events->setEmail($email);
            $events->setPhone($phone);
            $events->setAddress($address);
            $events->setZip($zip);
            $events->setCity($city);
            $events->setUrl($url);
       
           $em->flush();
            $this->addFlash(
                    'notice',
                    'Event Updated'
                   );
            return $this ->redirectToRoute('home' );
       }
       return  $this->render( '/events/edit.html.twig', array( 'events' => $events, 'form' => $form->createView()));
    }

    /**
     * @Route("/details/{id}", name="details")
     */
    public function details($id)
    {
        $events = $this->getDoctrine()->getRepository( 'App:Eventv')->find($id);
        return $this->render('events/details.html.twig', array('events' => $events));
    }

    /**
    * @Route("/delete/{id}", name="delete")
    */
    public function deleteAction($id){
        $em = $this->getDoctrine()->getManager();
        $events = $em->getRepository('App:Eventv')->find($id);
        $em->remove($events);
        $em->flush();
        $this->addFlash(
           'notice',
            'Event deleted'
        );
        return  $this->redirectToRoute('home');
}


}
